import { useContext } from "react";
import { Usercontext } from "./UserContext";


export const UseUserContext=()=>{return useContext(Usercontext)}