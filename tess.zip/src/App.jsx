import { Route, Routes } from "react-router-dom"
import Createlist from "./Components/Createlist"
import LoginPage from "./Pages/LoginPage"
import SignUpPages from "./Pages/SignUpPages"
import { Usercontextprovoider } from "./Service/Dbmethods/UserContext"
import HomePage from "./Pages/HomePage"

function App() {

  return (
    <>
      <Usercontextprovoider>
      <Routes>
        <Route path= "/" element={<LoginPage/>} />
        <Route path= "/home" element={<HomePage/>} />
        <Route path="/signup" element={<SignUpPages/>}/>
      </Routes>
      </Usercontextprovoider>
    </>
  )
}

export default App
